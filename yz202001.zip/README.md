# yz202001

Jianming Zhang*, Zi Ye, Xiaokang Jin, Jin Wang, Jin Zhang. Traffic sign detection based on multi-scale attention and spatial information aggregator

Submitted to Journal of Real-Time Image Processing

If the above manuscript is accepted, the code and data to the manuscript will be publicly available for free.
